
#import <UIKit/UIKit.h>

@interface AGCommon : NSObject

@end
